//Program to find number of grandchildren for a given string

#include<stdio.h>
#include<string.h>
#include<ctype.h>

struct pair
{
char father[10];
char child[10];
};


void Convert_to_Lower(char []);
int findChild(struct pair [],int,char []);

void main()
{
FILE *fp;
fp=fopen("file.txt","r");

int numPairs=0;
char c;

//Counting number of pairs in the file
do
{
	c=getc(fp);
	if(c=='\n')
		numPairs++;

}while(c!=EOF);

fseek(fp,0,SEEK_SET);

struct pair p[numPairs];

char grandfather[10];
int n=0;
int i;

//Input Line 1 : Name whose grandchildren are to be counted
printf("Enter the name: ");
scanf("%s",grandfather);

Convert_to_Lower(grandfather);

for(int i=0;i<numPairs;i++)
{
	fscanf(fp,"%s",p[i].child);
	fscanf(fp,"%s",p[i].father);

	Convert_to_Lower(p[i].child);
	Convert_to_Lower(p[i].father);
}

for(i=0;i<numPairs;i++)
{
	if(strcmp(grandfather,p[i].father)==0)
		n=n+findChild(p,numPairs,p[i].child);
}

printf("\nNo. of grandchildren = %d\n",n);

fclose(fp);
}

void Convert_to_Lower(char str[])
{
	for(int i=0;str[i]!='\0';i++)
		str[i]=tolower(str[i]);
}

int findChild(struct pair p[],int numPairs,char father[])
{
	int count=0;
	for(int i=0;i<numPairs;i++)
	{
		if(strcmp(p[i].father,father)==0)
			count++;
	}
	return count;
}

