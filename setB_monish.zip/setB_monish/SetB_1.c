//Program to delete pair of adjacent letters with same value in a string

#include<stdio.h>

void shift_by_2(char [],int,int);

void main()
{

int len;

//Input Line 1 : Length of String
printf("\nEnter the length of the string: ");
scanf("%d",&len);

char str[len];

//Input Line 2 : The string
printf("\nEnter the string: ");
scanf("%s",str);

for(int i=0;i<len-1;i++)
{
	if(str[i]==str[i+1])
	{
		shift_by_2(str,len,i);
		i=-1;
		len=len-2;
	}
}

if(str[0]=='\0')
	printf("\nEmpty String\n\n");
else
	printf("\n\nThe non-reducable form is : %s\n\n",str);

}

void shift_by_2(char str[],int l,int idx)
{
	int i;
	for(i=idx;i<=l-2;i++)
	{
		str[i]=str[i+2];
	}
}

