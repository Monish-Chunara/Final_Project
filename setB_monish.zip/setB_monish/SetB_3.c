//Program to reverse the order of bits in an unsigned integer number

#include<stdio.h>

void reverseBits(unsigned int);
int CountBits(unsigned int n);
void print_Binary(unsigned int);

int numBits;

void main()
{
unsigned int n;

//Input Line 1 : Number
printf("Enter the number: ");
scanf("%d",&n);

numBits = CountBits(n);

printf("\nBefore: ");
print_Binary(n);

reverseBits(n);

printf("\n");
}

//Function to reverse the order of bits and print the result
void reverseBits(unsigned int n)
{
	unsigned int rev=0;

	for(int i=0;i<numBits;i++)
	{
		if((n & (1<<i)) != 0)
		{
			rev = rev | (1<<(numBits-i-1));
		}
	}
	
	printf(" After: ");
	print_Binary(rev);
	
}

//Function to count number of bits
int CountBits(unsigned int n)
{
	int count=0;

	if(n==0)
		return 1;

	while(n!=0)
	{
		n=n>>1;
		count++;
	}

	return count;
}

//Function to print in binary form
void print_Binary(unsigned int n)
{
	for(int i=numBits-1;i>=0;i--)
	{
		n & (1<<i) ? printf("1") : printf("0");
	}
}
